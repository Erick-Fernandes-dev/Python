n = int(input("Digite um valor: "))
contador = 0

while contador <= n:
  if contador % 2 == 0:
    print(contador)
  contador = contador + 1
