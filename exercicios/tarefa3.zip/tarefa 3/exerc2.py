n = int(input("Digite um valor: "))
fat = 1
i = 1

while i <= n:
    fat = fat*i
    i = i + 1
print("o valor fatorial é:", fat)
