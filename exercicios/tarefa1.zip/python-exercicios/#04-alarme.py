#004

horas = 14
falta = 51 % 24
alarme = falta + horas

print('O alarme tocará às: ', alarme, ' horas')
