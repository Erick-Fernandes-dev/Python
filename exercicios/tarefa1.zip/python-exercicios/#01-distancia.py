#1) Escreva um programa que recebe do usuário uma distância em quilômetros e
#exibe essa mesma distância convertida para metros.
no = input("Digite seu nome")
print("Seu nome é", no)
n1 = str(input("Se o valor em kilometro e"))
n1 = int(input("entao a distancia em metro dele e:"))
print((no), "esta a", (n1), "m")
