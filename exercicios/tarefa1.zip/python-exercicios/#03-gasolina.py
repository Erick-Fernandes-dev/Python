gasolina = float(input("Digite o valor da gasolina"))
print("o valor da gasolina gasta e", gasolina)
km = float(input("Digite o valor percorrido"))
print("o valor percorrido foi", km)
mult = gasolina * km
print("o valor gasto em litro foi de ", gasolina, "e o valor percorrido em km foi", km, "alor final e", mult)
