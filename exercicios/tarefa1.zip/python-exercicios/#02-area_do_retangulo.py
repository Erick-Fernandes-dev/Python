base = int(input("Digite um valor"))
print("A base do retangulo é {}" .format(base))
altura = int(input("Digite mais um valor"))
print("A altura é", altura)
calculo = base * altura
print("A area do retangulo {}" .format(calculo))